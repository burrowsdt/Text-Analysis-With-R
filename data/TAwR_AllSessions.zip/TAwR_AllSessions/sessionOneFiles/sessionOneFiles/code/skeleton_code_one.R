## Code skeleton for Introduction to Text Analysis with R, Session 1 Code
## adapted from Jockers, Introduction to Text Analysis with R for Students of
## Literature

library(tm)
library(swirl)

## If desired, you can use swirl as an interactive training module to learn R
## basics and beyond. Load swirl with the command: swirl()

## Load text and stopwords into R

text.v <- scan("data/plainText/melville.txt", what="character", sep="\n")
stopwords.v <- scan("data/stoplist.csv", what="character", sep="\n")

## Identify and isolate metadata

start.v <- which(text.v == "CHAPTER 1. Loomings.")

end.v <- which(text.v == "orphan.")

start.metadata.v <- text.v[1:start.v -1]

end.metadata.v <- text.v[(end.v+1):length(text.v)]

metadata.v <- c(start.metadata.v, end.metadata.v)

## Identify and isolate novel

novel.lines.v <-  text.v[start.v:end.v]

## Clean and tokenize novel

novel.v <- paste(novel.lines.v, collapse=" ")

novel.lower.v <- tolower(novel.v)

novel.words.l <- strsplit(novel.lower.v, "\\W")

novel.words.v <- unlist(novel.words.l)

not.blanks.v  <-  which(novel.words.v!="")

novel.words.v <-  novel.words.v[not.blanks.v]

total.words.v <- length(novel.words.v)

## Working with raw frequencies

whale.hits.v <- length(novel.words.v[which(novel.words.v=="whale")])

novel.freqs.t <- table(novel.words.v)

sorted.novel.freqs.t <- sort(novel.freqs.t , decreasing=T)

plot(sorted.novel.freqs.t[1:10])

plot(sorted.novel.freqs.t[1:10], type="b", xlab="Top Ten Words", ylab="Word Count", xaxt = "n")
axis(1,1:10, labels=names(sorted.novel.freqs.t[1:10]))

## Taking out stop words and performing same frequency count

novel.stopwordsRemoved.v <- removeWords(novel.words.v, stopwords.v)

not.blanks.v  <-  which(novel.stopwordsRemoved.v!="")

novel.stopwordsRemoved.v <-  novel.stopwordsRemoved.v[not.blanks.v]

novel.frequenciesWithoutStopwords.t <- table(novel.stopwordsRemoved.v)

sorted.novel.frequenciesWithoutStopwords.t <- sort(novel.frequenciesWithoutStopwords.t , decreasing=T)

plot(sorted.novel.frequenciesWithoutStopwords.t[1:10], type="b", xlab="Top Ten Words", ylab="Word Count", xaxt = "n")
axis(1,1:10, labels=names(sorted.novel.frequenciesWithoutStopwords.t[1:10]))

## Working with relative frequencies - first, without stopwords

sorted.novel.rel.freqs.t <- 100*(sorted.novel.freqs.t/sum(sorted.novel.freqs.t))

plot(sorted.novel.rel.freqs.t[1:10], type="b",
     xlab="Top Ten Words", ylab="Percentage of Full Text", xaxt ="n")
axis(1,1:10, labels=names(sorted.novel.rel.freqs.t [1:10]))

## Then relative frequencies with stopwords removed (but against the full text)

sorted.novel.rel.cleanFreqs.t <- 100*(sorted.novel.frequenciesWithoutStopwords.t/sum(sorted.novel.freqs.t))

plot(sorted.novel.rel.cleanFreqs.t[1:10], type="b",
     xlab="Top Ten Words", ylab="Percentage of Full Text", xaxt ="n")
axis(1,1:10, labels=names(sorted.novel.rel.cleanFreqs.t [1:10]))

## Working with token distribution analysis - stop words included

n.time.v <- seq(1:length(total.words.v))

whales.v <- which(novel.words.v == "whale")

w.count.v <- rep(NA,length(n.time.v))

w.count.v[whales.v] <- 1

plot(w.count.v, main="Dispersion Plot of 'whale' in Moby Dick",
     xlab="Novel Time", ylab="whale", type="h", ylim=c(0,1), yaxt='n')
