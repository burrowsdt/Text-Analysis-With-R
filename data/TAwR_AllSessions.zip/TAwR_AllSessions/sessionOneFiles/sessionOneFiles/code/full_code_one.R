##
## Commented code for Jockers, Chapter 2 - "First Foray into Text Analysis with
## R"
##
## If working in the cloud, be sure to set your working directory. Use the
## setwd() function or go to the "Session" menu and follow "Set Working
## Directory"
##
## Remember, you can use the help function to get more information about any
## operation in R. For example, if you want more information about the "tolower"
## function, type help(tolower) -- or type ?tolower
## 

## Load tm package for dealing with stopwords, swirl for instruction

library(tm)
library(swirl)

## Read text into R and store as object text.v; read stopwords into r and store as stopwords.v
text.v <- scan("data/plainText/melville.txt", what="character", sep="\n")
stopwords.v <- scan("data/stoplist.csv", what="character", sep="\n")

## Note that the scan function also works with basic internet URLs. 
text.v.URL <- scan("https://www.gutenberg.org/files/2701/2701-0.txt", what="character", sep="\n")

## Call the text.v object to see its contents
text.v

## Call the first item of your object
text.v[1]

## How long is our object? (And what does "long" mean here?)
length(text.v)

## identify start and end points for slicing away metadata
start.v <- which(text.v == "CHAPTER 1. Loomings.")
end.v <- which(text.v == "orphan.")

## Store starting and ending metadata in two separate objects
start.metadata.v <- text.v[1:start.v -1]
end.metadata.v <- text.v[(end.v+1):length(text.v)]

## Use the markers to store the metadata and the novel in two separate objects
metadata.v <- c(start.metadata.v, end.metadata.v)
novel.lines.v <- text.v[start.v:end.v]

## Collapse chunks of novel.lines.v
novel.v <- paste(novel.lines.v, collapse=" ")

# Examine the length and contents of our novel.v object
length(novel.v)
novel.v[1]

## Use tolower() function to convert all characters in our string to lower case
novel.lower.v <- tolower(novel.v)

## Use strsplit() to separate into words
novel.words.l <- strsplit(novel.lower.v, "\\W")

## Use class() to determine an object's type or even more information with str()
class(novel.lower.v)
str(novel.words.l)

## Use unlist() to return to character vector
novel.words.v <- unlist(novel.words.l)

## Use which() to identify locations of specific words. Combine with length() for quantity.
which(novel.words.v=="whale")
length(which(novel.words.v=="whale"))

## Find and remove blank items in novel.words.v
not.blanks.v <- which(novel.words.v!="")
novel.words.v <- novel.words.v[not.blanks.v]

## find all instances of a word using which(); use length to count; measure against total words
which(novel.words.v=="whale")
novel.words.v[which(novel.words.v=="whale")]
whale.hits.v <- length(novel.words.v[which(novel.words.v=="whale")])
total.words.v <- length(novel.words.v)
whale.hits.v/total.words.v

## count number of unique words
length(unique(novel.words.v))

## use table() to build index of word frequencies; sort table by most frequent
novel.freqs.t <- table(novel.words.v)
sorted.novel.freqs.t <- sort(novel.freqs.t, decreasing=TRUE)

## create plot of ten most frequent words (two versions)
plot(sorted.novel.freqs.t[1:10])
plot(sorted.novel.freqs.t[1:10], type="c", xlab="Top Ten Words", ylab="Word Count", xaxt = "n")
axis(1,1:10, labels=names(sorted.novel.freqs.t[1:10]))

## Depending on our research, words like "the" and "a" and "him" --- articles,
## prepositions, pronouns, etc. --- may or may not be desirable. There are many
## ways to remove stopwords, but for our purposes we will create a separate set
## of objects for analyzing Moby Dick with our stopwords removed.

## First we create a list of words with the stopwords removed. This leaves
## blanks behind, so let's remove those blanks with the same operations we used
## previously.

novel.stopwordsRemoved.v <- removeWords(novel.words.v, stopwords.v)

not.blanks.v  <-  which(novel.stopwordsRemoved.v!="")

novel.stopwordsRemoved.v <-  novel.stopwordsRemoved.v[not.blanks.v]

## Now we can construct our raw frequency table and plot the results with a few
## adjustments to account for our new word list (novel.stopwordsRemoved.v)

moby.cleanFreqs.t <- table(novel.stopwordsRemoved.v)

sorted.novel.frequenciesWithoutStopwords.t <- sort(moby.cleanFreqs.t , decreasing=T)

plot(sorted.novel.frequenciesWithoutStopwords.t[1:10], type="b", xlab="Top Ten Words", ylab="Word Count", xaxt = "n")
axis(1,1:10, labels=names(sorted.novel.frequenciesWithoutStopwords.t[1:10]))

## End of Jockers Ch 2...
## Start of Jockers Ch 3

#Sorts and checks the frequency of words
sorted.novel.freqs.t["he"]
sorted.novel.freqs.t["she"]
sorted.novel.freqs.t["him"]
sorted.novel.freqs.t["her"]

#Notice how unlike the original novel.words.v in 
#which each word was indexed at a position in the vector, 
#here the word types are the indexes, and the values are 
#the frequencies, or counts, of those word tokens. 
#When accessing values in novel.words.v, you had to first 
#figure out where in the vector those word tokens resided. 
#Recall that you did this in two ways: you found "call," "me," and "ishmael" by entering:
novel.words.v[4:6]

#With the data in a table object (sorted.novel.freqs.t), 
#however, you get both numerical indexing and named indexing.
sorted.novel.freqs.t[1]
sorted.novel.freqs.t["the"]

#If you want to know just how much more frequent him is than her, 
#you can use the / operator to perform division.
sorted.novel.freqs.t["him"]/sorted.novel.freqs.t["her"]
sorted.novel.freqs.t["he"]/sorted.novel.freqs.t["she"]

#Comparing two novels requires compensating for the different lengths 
#of the novels, so you convert the raw counts to percentages by dividing 
#each count by a total count of all of the words in the whole text. 
#These are called "relative frequencies."

##Total number of words can be found in several ways, such as length() or sum()
length(novel.words.v)
sum(sorted.novel.freqs.t)

## But with some basic math we can convert raw counts to relative frequency percentages.
## Note: there are other ways we could write this code, such as
## sorted.novel.rel.freqs.t <- 100*(sorted.novel.freqs.t/length(novel.words.v))

sorted.novel.rel.freqs.t <- 100*(sorted.novel.freqs.t/sum(sorted.novel.freqs.t))

#Note that R recycles the result of sum(sorted.novel.freqs.t) and applies that
#result to each and every value in the sorted.novel.freqs.t variable. Recycling
#is a common operation in R and can be used in a number of ways.

#Having applied the above calculation to the sorted.novel.freqs.t object, you can 
#now access any word type and return its relative frequency as a percentage. 
#Because you have multiplied by 100, this percentage shows the number of occurrences 
#per every 100 words.

sorted.novel.rel.freqs.t["the"]
sorted.novel.rel.freqs.t["god"]
sorted.novel.rel.freqs.t["whale"]

#Plot the top ten words by relative frequency. xlab and ylab create labels
#The axis() allows you to modify the visual to include labels

plot(sorted.novel.rel.freqs.t[1:10], type="b",
     xlab="Top Ten Words", ylab="Percentage of Full Text", xaxt ="n")
axis(1,1:10, labels=names(sorted.novel.rel.freqs.t [1:10]))

## The "type" argument defines the type of graph to draw - in this case, "b"
## stands for "both," meaning both a point and a line plot. Type ?plot to see a
## list of plot types. And more information about the function's main arguments.
## Here is the same data drawn as a point plot.

plot(sorted.novel.rel.freqs.t[1:10], type="p",
     xlab="Top Ten Words", ylab="Percentage of Full Text", xaxt ="n")
axis(1,1:10, labels=names(sorted.novel.rel.freqs.t [1:10]))

## The axis() function adds an axis to the plot; the "1" designates the defined
## axis as the bottom axis, 1:10 provide the tick-mark divisions. Use ?axis to
## find out more information about its arguments.

plot(sorted.novel.rel.freqs.t[1:10], type="b",
     xlab="Top Ten Words", ylab="Percentage of Full Text")
axis(1,1:10, labels=names(sorted.novel.rel.freqs.t [1:10]))

## Since we have a wordlist with stopwords removed, let's look at relative
## frequencies using that list instead. Note that we are using the original
## length of Moby Dick (200+ k words) rather than our "new" length with
## stopwords removed. This may or may not be what we want, depending on our
## research questions.

sorted.novel.rel.cleanFreqs.t <- 100*(sorted.novel.frequenciesWithoutStopwords.t/sum(sorted.novel.freqs.t))

plot(sorted.novel.rel.cleanFreqs.t[1:10], type="b",
     xlab="Top Ten Words", ylab="Percentage of Full Text", xaxt ="n")
axis(1,1:10, labels=names(sorted.novel.rel.cleanFreqs.t [1:10]))

## End Ch 3 of Jockers
## Begin Ch 4 of Jockers

## Use length to find the last item in MD, then combine w/seq() to create a sequence vector

n.time.v <- seq(1:length(novel.words.v))

## If we want to use this sequence to start mapping a specific term like "whale"
## - we can use the which() function to find instances of the term

whales.v <- which(novel.words.v == "whale")

## Then use rep() to create a vector of null values the same length as n.time.v

w.count.v <- rep(NA,length(n.time.v))

## Then replace the NA with "1" wherever "whale" is found - use the whales.v
## object as an index within the w.count.v object

w.count.v[whales.v] <- 1

## Now use plot for a basic dispersion plot. Note that our "type" argument is
## "h" for histogram

plot(w.count.v, main="Dispersion Plot of 'whale' in Moby Dick",
     xlab="Novel Time", ylab="whale", type="h", ylim=c(0,1), yaxt='n')

## Setting yaxt to "no" suppresses the default axis markings/tick marks - which
## are unnecessary for our plot. Try the same plot without the yaxt argument.

plot(w.count.v, main="Dispersion Plot of `whale' in Moby Dick",
     xlab="Novel Time", ylab="whale", type="h", ylim=c(0,1))

## Let's adapt our code for another word: "ahab"

ahab.v <- which(novel.words.v == "ahab")
a.count.v <- rep(NA, length(n.time.v))
a.count.v[ahab.v] <- 1

## Plot that version

plot(a.count.v, main="Dispersion Plot of 'ahab' in Moby Dick",
     xlab="Novel Time", ylab="whale", type="h", ylim=c(0,1), yaxt='n')

## It is possible to display more than one visualization on the screen at a
## time. There are multiple ways to do this (with pros and cons for each). The
## below method is relatively easy. See ?split.screen for more information. It
## is important to use the close.screen function at the end in order to restore
## the standard screen defaults.

split.screen(c(1, 2))

screen(1)

plot(w.count.v, main="Dispersion Plot of 'whale' in Moby Dick",
     xlab="Novel Time", ylab="whale", type="h", ylim=c(0,1), yaxt='n')

screen(2)

plot(a.count.v, main="Dispersion Plot of 'ahab' in Moby Dick",
     xlab="Novel Time", ylab="ahab", type="h", ylim=c(0,1), yaxt='n')

close.screen(all = TRUE)

## Plot() does not lend itself to saving plots as objects. You can
## export/publish them for external use but you cannot store the plot itself as
## an object within your script - they must be drawn on demand. ggplot2 is a
## very popular plotting/visualization package that offers more options in this
## sense.

## Note: the below commented code completes ch 4 in Jockers. We will not cover
## this material in this particular workshop. You can run it on your own but be
## sure to supplement with the Jockers text. It introduces several complicated
## functions that benefit from more explanation than is included here.

## Clear the workspace and use the below code to restore early version of our text.
rm(list = ls())

text.v <- scan("data/plainText/melville.txt", what="character", sep="\n")
start.v <- which(text.v == "CHAPTER 1. Loomings.")
end.v <- which(text.v == "orphan.")
novel.lines.v <- text.v

## Use grep() to identify chapter breaks in the text. grep() is the native
## function for applying regular expressions in R. The first argument of grep()
## is the regex; the second argument is the target text.

chap.positions.v <- grep("^CHAPTER \\d", novel.lines.v)

## The chap.positions.v object now effectively marks our chapter headings (saved
## as character vectors). See this by using the chap.positions.v object to
## "call" those positions within the novel.lines.v vector.

novel.lines.v[chap.positions.v]

## Add a final line to our text to use as an endpoint

novel.lines.v <- c(novel.lines.v, "END")
last.position.v <- length(novel.lines.v)
chap.positions.v <- c(chap.positions.v , last.position.v)


## Jockers now introduces "for" loops. We are going to use them to separate out
## the content of each of Moby Dick's 135 chapters. To demonstrate a for loop in
## action, Jockers prints the index number of each heading in chap.positions.v
## in a single command.

for(i in 1:length(chap.positions.v)){
  print(chap.positions.v[i])
}

## Or this bit of code makes the operations of our "for" loop a bit more clear.
## Note that the loop's iterating arguments are the same as that of our first
## loop - what changed is the result of each iteration, the arguments given to
## our print() function

for(i in 1:length(chap.positions.v)){
  print(paste("Chapter ",i, "begins at position ",
              chap.positions.v[i]), sep="")
}

## Create two empty list objects to assist us in working through each chapter

chapter.raws.l <- list()
chapter.freqs.l <- list()

## Create a "for" loop that will identify the beginning and end of each chapter,
## then calculate raw and relative frequencies by chapter.

for(i in 1:length(chap.positions.v)){
  if(i != length(chap.positions.v)){
    chapter.title <- novel.lines.v[chap.positions.v[i]]
    start <- chap.positions.v[i]+1
    end <- chap.positions.v[i+1]-1
    chapter.lines.v <- novel.lines.v[start:end]
    chapter.words.v <- tolower(paste(chapter.lines.v, collapse=" "))
    chapter.words.l <- strsplit(chapter.words.v, "\\W")
    chapter.word.v <- unlist(chapter.words.l)
    chapter.word.v <- chapter.word.v[which(chapter.word.v!="")]
    chapter.freqs.t <- table(chapter.word.v)
    chapter.raws.l[[chapter.title]] <- chapter.freqs.t
    chapter.freqs.t.rel <- 100*(chapter.freqs.t/sum(chapter.freqs.t))
    chapter.freqs.l[[chapter.title]] <- chapter.freqs.t.rel
  }
}

## Use lapply() to find and store the frequency rate for "whale" in each chapter
## and store it in a list

whale.l <- lapply(chapter.freqs.l, '[', 'whale')

## We could use rbind() to construct a matrix of those values but instead
## Jockers uses "do dot call" (do.call) in conjunction with rbind. Jockers's
## example creates a list with three sets of three numbers

x <- list(1:3,4:6,7:9)

## then uses do.call to  transform that list into a matrix, where each
## set is itself a vector

do.call(rbind,x)

## Apply this same logic to our whale.l list (which has similar features)

whales.m <- do.call(rbind, whale.l)

## So do the same thing now with "ahab":

ahab.l <- lapply(chapter.freqs.l, '[', 'ahab')
ahabs.m <- do.call(rbind, ahab.l)

## We will use cbind() to bring these two matrices together column-wise, but
## first an example of matrices in action:

x <- c(1,2,3,4,5,6)
y <- c(2,4,5,6,7,8)
z <- c(24,23,34,32,12,10)
test.m <- cbind(x,y,z)

## Call for an item by its position i.e. objectName[row,column] or by column name where possible.

test.m[2,3]
test.m[2,]
test.m[,3]
test.m[,"y"]

## So to construct a matrix of frequencies for both "whale" and "ahab," create
## two vectors of those numbers and bind with cbind()

whales.v <- whales.m[,1]
ahabs.v <- ahabs.m[,1]
whales.ahabs.m <- cbind(whales.v, ahabs.v)
dim(whales.ahabs.m)

## We can name the columns using colnames()

colnames(whales.ahabs.m) <- c("whale", "ahab")

## Use barplot() to plot results

barplot(whales.ahabs.m, beside=T, col="grey")