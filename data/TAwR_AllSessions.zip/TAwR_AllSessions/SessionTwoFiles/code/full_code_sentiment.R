# Full code for Text Analysis with R, Session 2: Sentiment Analysis and Syuzhet

# Syuzhet is a package for sentiment analysis built by Matthew Jockers. Much of
# the code for this workshop waS adapted from the introductory vignette written
# for the package. You can find that extended tutorial and code here:
# https://cran.r-project.org/web/packages/syuzhet/vignettes/syuzhet-vignette.html. 

# Please note that as of this workshop Syuzhet is only usable for Latin alphabets.

library(syuzhet)
library(magrittr)

## Read our text into R and store it in an string object "text" - we'll do this
## with Syuzhet's get_text_as_string() function, though there are other options.
## [Note: our texts today were both taken from Project Gutenberg, but we have
## stripped the metadata from the files for the purposes of this workshop]

text <- get_text_as_string("data/awakening.txt")

## Last week we needed to perform a lot of cleaning to our text. Syuzhet's core
## functions have much of that built in. We'll use the getsentences() function
## to break our string into sentences.

text_sentences <- syuzhet::get_sentences(text)

## We can also tokenize by word, like we did last week when we analyzed word frequencies.

text_words <- get_tokens(text)

## We'll see how that makes a difference in a bit. But let's go ahead and run
## our first sentiment measurement using get_sentiment. The syuzhet package
## allows us to run sentiment measurements according to multiple dictionaries.
## We assign dictionaries by using the "method" argument. Note that the
## get_sentiment function does take time to run.

syuzhet_vector_sentences <- get_sentiment(text_sentences, method = "syuzhet")

## If we print the object we see the get_sentiment function's output: a
## measurement of each sentence's sentiment compiled into one vector

print(syuzhet_vector_sentences)

## As we said previously, we can run sentiment analysis at the level of
## individual words. Let's do that to compare our results

syuzhet_vector_words <- get_sentiment(text_words, method="syuzhet")

## We can actually use the get_sentiment_dictionary to see what each of the dictionaries we will be using looks like

get_sentiment_dictionary(dictionary="syuzhet")

get_sentiment_dictionary(dictionary="afinn")

get_sentiment_dictionary(dictionary="bing")

get_sentiment_dictionary(dictionary="nrc")


## Let's also run examples for each of the other methods: bing, afinn, and nrc

bing_vector_sentences <- get_sentiment(text_sentences, method="bing")
afinn_vector_sentences <- get_sentiment(text_sentences, method="afinn")
nrc_vector_sentences <- get_sentiment(text_sentences, method="nrc", lang = "english")

## Compare the first handful of values for each type - notice how different they
## are. One problem is that they all work with different scales. Jockers
## recommends using an R function, "sign" to simplify these results for
## comparative purposes. Here we have done that with the first six numbers in
## our sentiment vectors

methods_sign <- rbind(
  sign(head(syuzhet_vector_sentences)),
  sign(head(bing_vector_sentences)),
  sign(head(afinn_vector_sentences)),
  sign(head(nrc_vector_sentences))
)

print(methods_sign)

## The summary function provides a nice overview of each sentiment vector. We
## can use the summaries, for instance, to quickly compare each function

summary(syuzhet_vector_sentences)
summary(syuzhet_vector_words)

## We can also run sum() and mean() functions on each vector.
sum(syuzhet_vector_sentences)
sum(syuzhet_vector_words)

## Use the plot() function (type="l" argument) to plot a line graph of
## our syuzhet sentences vector

plot(
  syuzhet_vector_sentences,
  type="l",
  main="Example Plot Trajectory",
  xlab = "Narrative Time",
  ylab= "Emotional Valence"
)

## Lots of noise, right? Our goal is to understand how sentiment changes over
## the course of the novella as a whole. To clean this up, we can split our total
## novel into chunks (or bins)

percent_vals <- get_percentage_values(syuzhet_vector_sentences, bins=10)
plot(
  percent_vals,
  type="l",
  main="Chopin's The Awakening Using Percentage-Based Means", 
  xlab = "Narrative Time", 
  ylab= "Emotional Valence", 
  col="red"
)

## Or we may want to increase the number of bins, thus splitting the novel into smaller units

percent_vals <- get_percentage_values(syuzhet_vector_sentences, bins=20)
plot(
  percent_vals,
  type="l",
  main="Chopin's The Awakening Using Percentage-Based Means", 
  xlab = "Narrative Time", 
  ylab= "Emotional Valence", 
  col="red"
)

## Remember, too, that we can perform this same operation at the word level

percent_vals <- get_percentage_values(syuzhet_vector_words, bins=100)
plot(
  percent_vals,
  type="l",
  main="Chopin's The Awakening Using Percentage-Based Means", 
  xlab = "Narrative Time", 
  ylab= "Emotional Valence", 
  col="red"
)

#The get_dct_transform is similar to get_transformed_values function, 
#but it applies the simpler discrete cosine transformation (DCT) in place 
#of the fast Fourier transform. It's main advantage is in its better representation 
#of edge values in the smoothed version of the sentiment vector.

dct_values <- get_dct_transform(
  syuzhet_vector_sentences, 
  low_pass_size = 5, 
  x_reverse_len = 100,
  scale_vals = F,
  scale_range = T
)

plot(
  dct_values, 
  type ="l", 
  main ="Chopin's The Awakening using Transformed Values", 
  xlab = "Narrative Time", 
  ylab = "Emotional Valence", 
  col = "red"
)

#The simple_plot function takes a sentiment vector and applies three 
#smoothing methods. The smoothers include a moving average, loess, and 
#discrete cosine transformation. This function produces two plots stacked. 
#The first shows all three smoothing methods on the same graph. The second 
#graph shows only the DCT smoothed line, but does so on a normalized time axis. 

simple_plot(syuzhet_vector_sentences)

## The NRC Emotion lexicon categorizes words by their normative emotional
## content and sentiment. The syuzhet package allows you to see your text broken
## down across those values. Run the get_nrc_sentiment function on the original
## sentence or word vectors we created from The Awakening

nrc_data<-get_nrc_sentiment(text_sentences)

## Call the nrc_data object. Every row of this dataframe reflects a sentence's
## word count categorized by emotion. It also shows positive/negative valence
## scores (which are what our nrc sentiment vector was originally calculated
## from)

nrc_data

## This dataframe also makes it easy to identify specific items by their
## emotions category. Below, we examine all sentences that include an "anger"
## word; then all sentences that include a "joy" word; then all sentences that
## include "disgust"

angry_items <- which(nrc_data$anger > 0)
text_sentences[angry_items]

joy_items <- which(nrc_data$joy > 0)
text_words[joy_items]

disgust_items <- which(nrc_data$disgust > 0)
text_sentences[disgust_items]

## We can plot the percentage of each emotion's presence in the text as a bar graph
barplot(
  sort(colSums(prop.table(nrc_data[, 1:8]))), 
  horiz = TRUE, 
  cex.names = 0.7, 
  las = 1, 
  main = "Emotions in The Awakening", xlab="Percentage"
)

#The rescale_x_2 function rescales values to a normalized x and y axis so that
#texts of different lengths can be more easily compared. Assume that we want to
#compare the shapes produced by applying a moving average to two different
#sentiment arcs. 

## As an example, let's say we want to compare the sentiment arc of "The
#Awakening" to "The Yellow Wallpaper" by Perkins Gilman using the syuzhet
#dictionary. Let's read, tokenize, and calculate our sentiment vector for the
#text.

second_text <- get_text_as_string("data/yellowWallpaper.txt")
second_sentences <- syuzhet::get_sentences(second_text)
second_syuzhet_vector <- get_sentiment(second_sentences)

simple_plot(second_syuzhet_vector)

## Now we'll calculate a moving average for each novel's vector of raw values. 
#We'll use a window size equal to 1/10 of the overall length of the vector.

wdw_1 <- round(length(syuzhet_vector_sentences)*.1)
first_text_rolled <- zoo::rollmean(syuzhet_vector_sentences, k=wdw_1)
wdw_2 <- round(length(second_syuzhet_vector)*.1)
second_text_rolled <- zoo::rollmean(second_syuzhet_vector, k=wdw_2)

## Note that each novel's new moving average vectors are different lengths
length(first_text_rolled)
length(second_text_rolled)

## So Syuzhet has a rescaled_x_2 function to help normalize those lengths for
## comparative purposes

first_list <- rescale_x_2(first_text_rolled)
second_list <- rescale_x_2(second_text_rolled)

#We can then plot the two lines on the same graph even though they are of different lengths:
plot(first_list$x, 
     first_list$z, 
     type="l", 
     col="blue", 
     xlab="Narrative Time", 
     ylab="Emotional Valence")
lines(second_list$x, second_list$z, col="red")

#Because two vectors won't be the same length, we can sample them:
first_sample <- seq(1, length(first_list$x), by=round(length(first_list$x)/100))
second_sample <- seq(1, length(second_list$x), by=round(length(second_list$x)/100))

plot(first_list$x[first_sample], 
     first_list$z[first_sample], 
     type="l", 
     col="blue",
     xlab="Narrative Time (sampled)", 
     ylab="Emotional Valence"
)
lines(second_list$x[second_sample], second_list$z[second_sample], col="red")

## As a final exercise, let's compare the various calculations made by the
## syuzhet package with another package devoted to sentiment analysis. The
## package "sentimentr" works similarly to the syuzhet package. But it
## explicitly tries to account for "valence shifters" - small parts of speech or
## phrases that can negate or change the emotional valence of a given word. 

## sentimentr tokenizes at the sentence level. We have already transformed "The
## Awakening" into a vector of sentences, but let's use its get_sentences
## function anyway and pipe it into the package's sentiment() function

library(sentimentr)

sentiment_sentimentr <- as.character(text) %>% 
  sentimentr::get_sentences() %>% 
  sentimentr::sentiment()

## Call our new object and note that the sentimentr package automatically put
## the results into a table/data.frame. It gave every sentence its own ID and
## counted each sentence's words.

sentiment_sentimentr

# Let's plot these results. Sentimentr conveniently runs its results through
# syuzhet's get_transformed_values() to smooth and scale the results to the duration of the
# novella

plot(sentiment_sentimentr)

# Compare with our original syuzhet plot 

plot(
  dct_values, 
  type ="l", 
  main ="Chopin's The Awakening using Transformed Values", 
  xlab = "Narrative Time", 
  ylab = "Emotional Valence", 
  col = "red"
)

# Note that the results here are actually pretty similar. But in some cases -
# particularly when analyzing everyday speech or particular types of literature
# - the results can be quite different. See the sentimentr documentation and
# accompanying vignettes for detailed information