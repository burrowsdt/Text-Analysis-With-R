## The code below is an introduction to Stylo as considered in our third 'Text
## Analysis with R' workshop (Stylometrics with Stylo). Although the first section uses the
## command/console line, the rest of the code simply calls the GUI and the
## program can be explored from there. You cannot use Stylo's GUI with RStudio
## Cloud; you must use the desktop application or another desktop-based IDE. 

## Remember that functions on the package only work if your folders are set up
## correctly. Be sure to set your working directory and consult stylo's
## documentation for details.

library(stylo)
setwd("C:/yourfilepath/sessionThreeFiles")

## load galbraith dataset (from stylo)

data(galbraith)

## Use rownames() and colnames() to see how the data is structured
rownames(galbraith)
colnames(galbraith)

## Run a sample cluster analysis on the dataset - run summary(my.discovery) to
## see list of variables created by results 

## The resulting dendrogram presents a basic tree showing the natural clustering
## of each author, with galbraith nicely tucked into rowling's section

galbraithCA <- stylo(
  frequencies = galbraith,
  analysis.type = "CA",
  write.png.file = TRUE,
  custom.graph.title = "Robert Galbraith",
  gui = FALSE
)

## Use summary() to see list of items created by stylo during analysis
summary(galbraithCA)

## Follow instructions to examine one of those items like so:
galbraithCA$distance.table
galbraithCA$list.of.edges

## Perform the same with the Lee dataset

data(lee)
rownames(lee)

lee.results <- stylo(
  frequencies = lee,
  analysis.type = "CA",
  write.png.file = TRUE,
  custom.graph.title = "Harper Lee",
  gui = FALSE
)

## The following uses the mfw.min/mfw.max setting to 1500 - this essentially
## means that the distance calculation will be performed on the first 1500 most
## frequent words in the entire corpus

lee.results.mfw <- stylo(
  frequencies = lee,
  analysis.type="CA",
  mfw.min = 1500,
  mfw.max = 1500,
  custom.graph.title="Harper Lee 2",
  write.png.file = TRUE,
  gui = FALSE)

## We can use the command line to work with the Federalist papers if we want, like so

fed.results.mfw <- stylo(
  analysis.type="CA",
  mfw.min = 1500,
  mfw.max = 1500,
  custom.graph.title="Harper Lee 2",
  write.png.file = TRUE,
  gui = FALSE)

## But the GUI is convenient and will do what we need it to do. The below
## functions will call the primary stylo functions. stylo() can be used for
## cluster analysis, PCA, and other methods of measuring the distance of between
## texts. These will produce dendograms, scatterplots as their visualizations.
## stylo() examines all texts included in your corpus directory.

stylo()

## oppose() can be used to chart the "preferred" and "avoided" words of one
## author compared to another. If using the provided data set, be sure to set
## the slice overlap to 500 words - anything higher will receive an error.
## oppose() compares text in your "primary_set" folder against texts in your
## "secondary_set" folder.

oppose()

## We can use the rolling.classify() to examine authorship/style sequentially
## within a given text but we need to set some additional arguments. There are
## three possible classification methods: "svm," "nsc," and "delta." This will
## train the computer on texts in your "reference_set" folder and then analyze
## the text in your "test_set" folder.

rolling.classify(write.png.file = TRUE, classification.method = "svm", 
                 mfw=100, training.set.sampling = "normal.sampling", 
                 slice.size = 500, slice.overlap = 100)

## You can use the networkD3 package to begin working with network visualizations of a cluster analysis

install.packages("networkD3")
library("networkD3")
stylo.network()

## But note, too, that you could use some of the material generated via stylo's
## analyses to assemble your own dataset for use in Gephi or a network
## application of your choice